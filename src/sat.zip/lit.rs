use std::ops::Not;
use std::fmt;
use std::cmp::*;
use lit::LitValue::*;

#[derive (Debug, Copy, Clone, PartialEq, Eq, PartialOrd, Ord)]
pub struct Var {
	num: usize
}

impl Var {
	pub fn new(num: usize) -> Self {
		Var {
			num: num,
		}
	}
	
	fn get_num(&self) -> usize {
		self.num
	}
}

impl fmt::Display for Var {
    fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
        write!(f, "{}", self.num)
    }
}

#[derive (Debug, Copy, Clone)]
pub enum LitValue {l_true, l_false, l_undef}

impl Not for LitValue {
	type Output = LitValue;
	
	fn not(self) -> LitValue {
		match self {
			l_true => l_false,
			l_false => l_true,
			l_undef => l_undef,
		}
	}
}

impl fmt::Display for LitValue {
	fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
		match *self {
			l_true => write!(f, "1"),
			l_false => write!(f, "0"),
			l_undef => write!(f, "x"),
		}
	} 
}

impl PartialEq for LitValue {
	fn eq(&self, other: &LitValue) -> bool {
		match *self {
			l_true => match *other {
				l_true => true,
				l_false => false,
				l_undef => true,
			},
			l_false => match *other {
				l_true => false,
				l_false => true,
				l_undef => true,
			},
			l_undef => true,
		}
	}
}

impl Eq for LitValue {}

#[derive (Debug, Copy, Clone)]
pub struct Lit {
	var: Var,
	value: LitValue,
}

impl Lit {
	pub fn new(var: Var) -> Self {
		Lit {
			var: var,
			value: l_true,
		}
	}
	
	pub fn from(var: Var, value: LitValue) -> Result<Self, String> {
		match value {
			l_true | l_false => Ok(Lit {
					var: var,
					value: value,
				}),
			l_undef => Err("undefined value".to_string()),
		}
	}
	
	pub fn var_num(&self) -> usize {
		self.var.get_num()
	}
	
	pub fn get_value(&self) -> LitValue {
		self.value
	}
}

impl Not for Lit {
	type Output = Lit;

	fn not(self) -> Lit {
		Lit {
			var: self.var,
			value: !self.value,
		}
	}
}

impl PartialOrd for Lit {
	fn partial_cmp(&self, other: &Lit) -> Option<Ordering> {
		Some(self.cmp(other))
	}
}

impl Ord for Lit {
	fn cmp(&self, other: &Lit) -> Ordering {
		self.var.cmp(&other.var)
	}
}

impl PartialEq for Lit {
	fn eq(&self, other: &Lit) -> bool {
		self.var == other.var && self.value == other.value
	}
}

impl Eq for Lit {}

impl fmt::Display for Lit {
    fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
    	if self.value == l_true {
	        write!(f, "({})", self.var)
    	}else {
	    	write!(f, "(~{})", self.var)
    	}
    }
}

#[derive (Debug)]
pub struct Clause {
	vec_lit: Vec<Lit>
}

impl Clause {
	pub fn new() -> Self {
		Clause {
			vec_lit: Vec::<Lit>::new(),
		}
	}
	
	pub fn push(&mut self, lit: Lit) {
		self.vec_lit.push(lit);
	}
	
	pub fn len(&self) -> usize {
		self.vec_lit.len()
	}
}

impl fmt::Display for Clause {
	fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
		write!(f, "[").unwrap();
		for i in 0..self.vec_lit.len() {
			if i != 0 {
				write!(f, "\\/").unwrap();
			}
			write!(f, "{}", self.vec_lit[i]).unwrap();
		} 
		write!(f, "]")
	}
}