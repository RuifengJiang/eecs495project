use lit::*;
use lit::LitValue::*;
use std::ops::*;
use std::fmt;
use std::cmp::*;

#[derive (Debug)]
pub struct Solver {
	clause: Vec<Clause>,
	num_var: usize,
	model: Vec<LitValue>,
}

impl Solver {
	pub fn new() -> Self {
		Solver {
			clause: Vec::<Clause>::new(),
			num_var: 0,
			model: Vec::<LitValue>::new(),
		}
	}
	
	pub fn new_var(&mut self) -> Var {
		let num = self.num_var;
		self.model.push(l_undef);
		self.num_var += 1;
		Var::new(num)
	}
	
	pub fn add_clause(&mut self, clause: Clause) -> bool {
		if clause.len() == 1 {
			
		}else {
			for i in 0..clause.len() {
				
			}
		}
		self.clause.push(clause);
		false
	}
}