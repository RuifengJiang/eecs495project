use lit::*;
use lit::LitValue::*;
use solver::Solver;

mod lit;
mod solver;

fn main() {
	let mut solver = Solver::new();
	let v1 = solver.new_var();
	let v2 = solver.new_var();
	
	let l1 = Lit::new(v1);
	let l2 = Lit::from(v2, l_false).unwrap();
	let l3 = Lit::from(v2, l_true).unwrap();

	println!("{}\n{}", v1, v2);	
	println!("{}\n{}\n{}", l1, l2, l3);
	println!("{}", l2 == l3);
	
	let mut lits = Clause::new();
	lits.push(l1);
	lits.push(l2);
	lits.push(l3);
	
	println!("{}", lits);
	
	println!("{}", l_true == l_undef);
}